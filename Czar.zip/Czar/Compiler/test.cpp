// test.cpp
#include <string>
#include <vector>
#include <initializer_list>
using namespace std;

struct SizeArray {
	SizeArray(){};
	SizeArray(int sz, initializer_list<string> lns){
		this->size = sz;
		this->content = lns;
	}
	SizeArray(&&SizeArray other) {
		this->size = other.size;
		this->content = other.size;
	}
	unsigned size;
	vector<string> content;
};

SizeArray test_case = new SizeArray(2, {"String -> go = new String('L');", " // Does stuff and things"});

void update(&SizeArray);
&SizeArray convert_1(&SizeArray);
&SizeArray convert_2(&SizeArray);
&SizeArray convert_3(&SizeArray);
&SizeArray convert_4(&SizeArray);
&SizeArray convert_5(&SizeArray);
&SizeArray convert_6(&SizeArray);
&SizeArray convert_7(&SizeArray);
&SizeArray convert_8(&SizeArray);
&SizeArray convert_9(&SizeArray);


void update(&SizeArray array) {
	array.size = array.content.size();
}

&SizeArray convert_1(&SizeArray array) {
	// Cycle through all lines in array
	*string current;
	for(int line = 0; line < array.size; line++) {
		update(array);
		current = &array.content[line];
		for(char c:current){
			cout << c << std::endl;
		}
	}
	return array;
}

&SizeArray convert_2(&SizeArray array) {
	return array;
}

&SizeArray convert_3(&SizeArray array) {
	return array;
}

&SizeArray convert_4(&SizeArray array) {
	return array;
}

&SizeArray convert_5(&SizeArray array) {
	return array;
}

&SizeArray convert_6(&SizeArray array) {
	return array;
}

&SizeArray convert_7(&SizeArray array) {
	return array;
}

&SizeArray convert_8(&SizeArray array) {
	return array;
}

&SizeArray convert_9(&SizeArray array) {
	return array;
}


int main() {
	convert_1(test_case);
	return 0;
}