#include <string>

#ifndef LEXER_H
#define LEXER_H

class Lexer {
public:
	Lexer();
	Lexer(std::string);
	~Lexer();
	void convert();
private:
	void set_string(std::string);
}